<div class="footer">
     <div class="container">
        <div class="row">
        <div class="col-sm-offset-2">      
        <p class="text-muted">版权所有© 广州市竣达智能软件技术有限公司 2009-2013　保留一切权利 粤ICP备09019571号</p>
         </div>        
        </div>       
      </div>
</div>
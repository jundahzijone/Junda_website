<html>
<head>
<style type="text/css" media="screen">

.nav > li .dropdown-menu {
margin: 0;
}
.nav > li:hover .dropdown-menu {
display: block;
}


</style>


<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
    <title>竣达技术-UPS监控技术专家</title>
    <link rel="icon" href="images/favicon.ico" type="image/x-ico">
    <script src="extlib/jquery-1.11.1.min.js" type="text/javascript" charset="utf-8"></script>
    <link rel="stylesheet" href="extlib/bootstrap-3.3.5-dist/css/bootstrap.min.css">
    <script src="extlib/bootstrap-3.3.5-dist/js/bootstrap.min.js" type="text/javascript" charset="utf-8" ></script>
    <script src="extlib/bootstrap-3.3.5-dist/js/tooltip.js" type="text/javascript" charset="utf-8" ></script>
    <script src="extlib/bootstrap-3.3.5-dist/js/carousel.js" type="text/javascript" charset="utf-8" ></script>
</head>
<body>
    <div class="container">

     <div class="row">
         <div class="col-sm-8">
            <a href="index.php" title="junda_home">
              <img src="images/junda-logo-small.png" height="36" width="227" alt="junda_logo"><br>
              <span style="color:blue">
               因为专注，所以专业
              </span>
            </a>
         </div>
         <div class="col-sm-4">
            <a href="http://e.t.qq.com/junda-tech?preview" title="txwb" target="_black">
              <img src="images/txwb.jpg" height="26" width="29" alt="junda_txwb">
            </a> 
         </div>     
     </div>
     <br>
    <!-- 主菜单下拉菜单  -->
    <div class="row">
    <div class="col-sm-8">
    <ul class="nav nav-tabs nav-pills">
        <li role="presentation" class="active"><a href="index.php">公司首页</a></li>


        <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">产品介绍</a>
            <ul class="dropdown-menu" style="z-index:5">
                <li><a href="product.php" data-toggle="tooltip" data-placement="bottom">UPS监控管理</a></li>
                <li><a href="">电池巡检管理</a></li>
                <li><a href="">工厂合作配套</a></li>
                <li><a href="">环境监控扩展</a></li>

                <li role="separator" class="divider"></li>

                <li><a href="">应用方案</a></li>
            </ul>

        </li>


        <li role="presentation"><a href="usercase.php" title=""  data-toggle="tooltip" data-placement="bottom" title="应用方案">应用方案</a></li>
         

        <li role="presentation"><a href="feedback.php" data-toggle="tooltip" data-placement="bottom" title="产品反馈">产品反馈</a></li>

        <li role="presentation"><a href="support.php"  data-toggle="tooltip" data-placement="bottom" title="技术支持">技术支持</a></li>
        <li role="presentation"><a href="aboutjundatech.php"  data-toggle="tooltip" data-placement="bottom" title="关于我们">关于我们</a></li>
    </ul>
    </div>
    </div>